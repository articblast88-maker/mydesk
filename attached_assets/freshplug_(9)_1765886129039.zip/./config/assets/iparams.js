
app.initialized().then(client => {
    window.client = client;
    // fsApiChange();
}, error => {
    console.error('Error: Failed to init the app.')
    console.error(error);
}
);

function fsApiChange(arg) {
    var domain = utils.get("freshsales_domain")
    var password = arg
    let timeout;
    return new Promise(function (resolve, reject) {
        clearTimeout(timeout);
        timeout = setTimeout(function () {
            if (domain && password) {
                if (domain.includes("http")) {
                    console.log("domain", domain)
                    let fsURL = domain.split("://")[1];
                    fsURL = fsURL.split(".myfreshworks")
                    domain = fsURL[0];

                }
                else {
                    if (domain.includes(".myfreshworks.com")) {
                        let fsURL = domain.split(".myfreshworks");
                        domain = fsURL[0]
                    }
                    else {
                        domain = domain;
                    }
                }
                 client.request.invokeTemplate("getFields", {
                    context: {
                        domain: domain,
                        authorization: password
                    },
                }).then(function (data) {
                    console.log("success")
                    resolve()
                }).catch(function (err) {
                    console.log("failure")
                    reject( "Invalid Freshsales Domain Name/API key")
                })
            }
        });
    }, 500);
}
