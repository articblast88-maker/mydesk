const moment = require('moment-timezone');
const { logo } = require('./lib/constant');
exports = {
  onTicketUpdateHandler: async function (args) {
    try {
      const { data, iparams, account_id: accountId } = args;
      const ticket = data.ticket;
      const customFields = ticket.custom_fields;
      const ticketType = customFields[`cf_ticket_type_${args['account_id']}`];

      if (ticketType === "Delivery Challan") {
        const ticketID = ticket.id;
        const dcStatus = customFields[`cf_dc_status_${accountId}`];
        const dcNumber = customFields[`cf_dc_${accountId}`];
        const submittedDate = customFields[`cf_dc_submitted_date_${accountId}`]
        const requesterEmail = data.requester.email;

        const sapStatuses = iparams.sapStatuses.split(",");
        const emailStatuses = iparams.emailStatuses.split(",");
        if (sapStatuses.includes(String(dcStatus)) || emailStatuses.includes(String(dcStatus))) {
          const res = await $request.invokeTemplate("filterAssetCustomObject", {
            context: { path: `dc_no=${dcNumber}&page_size=100` }
          });
          const assets = JSON.parse(res.response).records
          const assetDetails = assets.map(asset => ({
            swap_category: asset.data.swap_category,
            asset_status: asset.data.asset_status,
            smc: asset.data.smc,
            faulty_sr_no: asset.data.faulty_sr_no,
            asset_number: asset.data.asset_number
          }));
          const emailContent = await constructEmailContent(assetDetails, dcNumber, requesterEmail, submittedDate);
          await emailAssetDetails(emailContent, ticketID, args, dcNumber);
        }
      } else {
        console.log(`Ticket type is not DC for ticket #${args['data']['ticket']['id']}`)
      }
    } catch (error) {
      console.error("Error in onTicketUpdateHandler:", error);
    }
  },
  generateSequenceNumber: async function ({ regionCode: region }) {
    try {
      // Get current date in YYMMDD format
      const datePart = moment().tz('Asia/Kolkata').format("YYMMDD");
      let serialNumber;
      let sequenceNumber;

      // Retrieve the last CR sequence number for the agent's region from the database
      const { lastSerialNumber, lastDate } = await getDataFromDB(region);

      if (lastSerialNumber === null && lastDate === null) {
        console.log(`DB record not available for Region: ${region}`)
        serialNumber = '001';
        // Combine the region code, date, and serial number
        sequenceNumber = region.toUpperCase() + datePart + serialNumber;

        // Store data in the database
        await $db.set(region, { lastSerialNumber: serialNumber, lastDate: datePart });
        console.log("Stored Sequence Number in DB", sequenceNumber);

        renderData(null, { generatedSequenceNumber: sequenceNumber });
      } else {
        // Update the existing record in the database
        console.log(`DB record is available for Region: ${region}, SerialNumber: ${lastSerialNumber}, date: ${lastDate}`);
        // Increment the serial number or start from 001 if it's the first time for the day and region
        serialNumber = (lastSerialNumber !== null && lastDate === datePart) ? incrementSerialNumber(lastSerialNumber) : '001';
        // Combine the region code, date, and serial number
        sequenceNumber = region.toUpperCase() + datePart + serialNumber;


        // Update data in the database
        await $db.update(region, "set", { lastSerialNumber: serialNumber, lastDate: datePart });
        console.log(` Upadated DB record  for Region: ${region}, SerialNumber: ${serialNumber}, date: ${datePart}`);
        console.log("updated Sequence Number in DB", sequenceNumber);

        renderData(null, { generatedSequenceNumber: sequenceNumber });
      }
    } catch (error) {
      console.error("Error while generating Sequence number", error);
      renderData(error);
    }
  },
  initiateDC: async function (args) {
    console.log("Initiating DC update");
    try {
      const path = `distributor_code=${args.dtCode}&dc_no=%00&asset_status=Active&asset_status=In%20Repair&asset_status=Defective&asset_type=CARDLESS&asset_type=Set%20Top%20Box&page_size=100`;
      const res = await $request.invokeTemplate("filterAssetCustomObject", { context: { path } });
      const assetsResp = JSON.parse(res.response).records;
      const submittedAt = moment().tz('Asia/Kolkata');
      const createdAt = moment.tz(args.dcCreatedDate, 'Asia/Kolkata');

      // Prepare update payloads for all selected assets
      const updatePromises = args.selectedAssets.map(async (assetId) => {
        const assetData = assetsResp.find(obj => obj.display_id === assetId);
        const payload = {
          display_id: assetData.display_id,
          version: assetData.version,
          data: {
            ...assetData.data, // Include all existing data
            dc_no: args.generatedSequenceNumber,
            dc_submitted_date: submittedAt.format("YYYY-MM-DD"),
            dc_submitted_time: submittedAt.format("hh:mm:ss A"),
            asset_shipping_status: "In-Transit",
            dc_ticket_id: `${args.ticketId}`,
            dc_created_date: createdAt.format("YYYY-MM-DD")
          }
        };
        await updateAsset(assetData.display_id, payload);
      });

      // Execute all update promises concurrently
      await Promise.all(updatePromises);

      // Update the ticket after all assets are updated
      await updateTicket(args, submittedAt);

      // Render data with no error
      renderData(null);
    } catch (error) {
      console.error("Error in initiateDC:", error);
      // Render data with error
      renderData(error);
    }
  },
  getEmailContent: async function (args) {
    try {
      const emailContent = await constructEmailContent(args.assetDetails, args.dcNumber, args.emailID, args.submittedDate);
      renderData(null, { emailContent });
    }
    catch (error) {
      console.log(error);
      renderData(error)
    }
  }
};

async function getDataFromDB(region) {
  try {
    const dbData = await $db.get(region);
    const { lastSerialNumber, lastDate } = dbData;
    return { lastSerialNumber, lastDate };
  } catch (error) {
    console.log("Error while fetching region Data from db", error);
    return { lastSerialNumber: null, lastDate: null };

  }
}


function incrementSerialNumber(serialNumber) {
  const incrementedNumber = (parseInt(serialNumber, 10) % 999 + 1).toString().padStart(3, '0');
  return incrementedNumber;
}

async function fetchAddress(zone) {
  return $request.invokeTemplate("filterCustomObject", {
    context: { value: zone }
  });
}
async function fetchPartnerDetails(email) {
  return $request.invokeTemplate("getDtcode", {
    context: { id: encodeURIComponent(email) }
  });
}
async function updateTicket(args, submittedAt) {
  try {
    const bodyPayload = {
      custom_fields: {
        cf_dc: args.generatedSequenceNumber,
        cf_dt_code: args.dtCode,
        cf_dt_name: args.dtName,
        cf_dc_status: "Pending",
        cf_dc_submitted_date: submittedAt.format('YYYY-MM-DD hh:mm:ss A')
      }
    };

    await $request.invokeTemplate("updateTicket", {
      context: { id: args.ticketId },
      body: JSON.stringify(bodyPayload)
    });

    console.log("Ticket updated successfully");
  } catch (error) {
    console.error("Error while updating ticket:", error);
  }
}
async function updateAsset(assetId, payload) {
  try {
    await $request.invokeTemplate("updateAssetCustomObject", {
      context: { id: assetId },
      body: JSON.stringify(payload)
    });
    console.log(`Asset ${assetId} updated successfully`);
  }
  catch (error) {
    console.error(`Asset ${assetId} update failed`, error);
  }
}

async function emailAssetDetails(content, ticketID, args, dcNumber) {
  try {
    let emailBody
    const emailIds = args['iparams']['notify_mail'];
    if (emailIds) {
      const toEmail = emailIds;
      emailBody = {
        "EmailToId": toEmail,
        "EmailToName": emailIds,
        "EmailSubject": `Delivery Challan#${dcNumber} Submitted`,
        "EmailBody": `${content}`,
        "EmailidCc": "",  //comma separated values
        "EmailidBcc": "" //comma separated values
      }
    } else {
      console.log("No email IDs are configured to email Asset details.")
    }
    const token = await generateToken(args);

    let emailRequest = await $request.invokeTemplate("sendEmail", { context: { token: token }, body: JSON.stringify(emailBody) })
    let dcStatusPayload = {};
    const dcFieldName = args['iparams']['dc_status_field'];
    const emailResponse = JSON.parse(emailRequest.response)
    console.log("emailResponse", emailResponse.response)
    if (emailResponse.response == 'Success') {
      console.log(`Email sent Successfully for Ticket# ${ticketID}`);
      dcStatusPayload[dcFieldName] = "Successful";
      console.log("dcStatusPayload", dcStatusPayload)
    }
    else {
      dcStatusPayload[dcFieldName] = "Email Failed";
      console.log("dcStatusPayload", dcStatusPayload)
      console.log(`Error while sending emailing asset details for Ticket# ${ticketID}`);

    }
    await updateTicketProperties(dcStatusPayload, ticketID)

  } catch (error) {
    console.log(`Error while emailing asset details for Ticket# ${ticketID}`);
    console.log(error);
  }
}
async function generateToken(args) {
  try {

    const userName = args.iparams.token_username
    const password = args.iparams.token_password;
    const authKey = args.iparams.token_authkey;
    const tokenBody = { userName, password, authKey }
    const tokenResult = await $request.invokeTemplate("getToken", { context: {}, body: JSON.stringify(tokenBody) });
    let token = JSON.parse(tokenResult.response)
    return token.data
  }
  catch (err) {
    console.error("Error while generating token", err)
  }

}

async function updateTicketProperties(payload, ticketID) {
  let bodyPayload = {};
  bodyPayload['custom_fields'] = payload;
  try {
    await $request.invokeTemplate("updateTicket", {
      context: {
        id: ticketID,
      },
      body: JSON.stringify(bodyPayload)
    });
    console.log(`Successfully updated DC status for ticket#${ticketID}`);
  } catch (error) {
    console.log(`Error in the Updating DC status for ticket#${ticketID}`, error.response)
  }
}
async function constructEmailContent(assets, dcNum, emailAddress, submittedDate) {
  try {
    // Fetch partner details
    const salesAccountResp = await fetchPartnerDetails(emailAddress);
    const salesAccount = JSON.parse(salesAccountResp.response).sales_accounts.sales_accounts[0] || {};
    const region = salesAccount?.custom_field?.cf_states || '-';
    const fromAddress = salesAccount?.address || '-';
    const salesAccountGst = salesAccount?.custom_field?.cf_cst_no || '-';
    const salesAccountDtCode = salesAccount?.custom_field?.cf_dt_code || '-';
    const companyName = salesAccount.name;
    const cityName = salesAccount.city;
    const zipcode = salesAccount.zipcode

    // Fetch address details
    const addressDetailsResp = await fetchAddress(region);
    const addressDetail = JSON.parse(addressDetailsResp.response).records;
    const { warehouse_gstin: gst = "-", zone_address: zoneAddress = "-", warehouse_address: whAddress = "-" } = (addressDetail[0] && addressDetail[0].data) || {};

    // Filter assets based on types
    const inWtyAssets = [];
    const outWtyAssets = [];
    const radAssets = [];

    assets.forEach(asset => {
      if (asset.asset_status === "Defective") {
        radAssets.push(asset);
      } else if (["OUTWTY", "FOC", "SVCWTY"].includes(asset.swap_category)) {
        outWtyAssets.push(asset);
      } else {
        inWtyAssets.push(asset);
      }
    });
    const inWtyAssetslist = generateAssetList(inWtyAssets);
    const outWtyAssetslist = generateAssetList(outWtyAssets);
    const radAssetslist = generateAssetList(radAssets);

    let emailContent = `<!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <style>
      .list {
        display: flex;
        flex-wrap: wrap;
        max-width: 80%; /* Adjust this value to your desired width */
      }
        .list p:not(:last-child):after {
        content: ",";
        margin-right: 5px;
        }
          .sideHead {
              font-size: 14px;
              font-weight: bold;
          }
  
          p {
              font-size: 14px;
              margin: 5px 0px;
          }
  
          td {
              padding: 0px 10px;
          }
  
          /* Style for the second table */
          table.defective-table {
              border-collapse: collapse;
              width: 100%;
          }
  
          table.defective-table th,
          table.defective-table td {
              border: 1px solid #ffffff; /* Set border color to match background color */
              padding: 5px;
              text-align: left;
              font-size: 14px;
              vertical-align: top;
              horizontal-align:left;
          }
          .subCategory {
            color: hsl(0deg 0% 40%);
        }
      </style>
  </head>
  <body>
  <img id="logo" src=${logo}>
      <table width="100%" cellspacing="0" cellpadding="0" border="0">
      <tr>
      <td colspan="2" style="text-align: center; padding-bottom: 20px;">
          <div class="sideHead">Delivery Challan:</div>
      </td>
  </tr>
      <tr>
      <td width="50%">
          <div class="sideHead">DC Num:</div>
          <p>${dcNum || "-"}</p>
          <div class="sideHead">From:</div>
          <p>
              ${salesAccountDtCode}<br>
              ${companyName}<br>
              ${fromAddress}<br>
              ${cityName}<br>
              ${zipcode}<br>
              ${region}<br>
          </p>
      </td>
      <td width="50%">
          <div class="sideHead">Zonal Office:</div>
          <p>
              ${zoneAddress}
          </p>
          <div class="sideHead">Date:</div>
          <p>${submittedDate || "-"}</p>
          <div class="sideHead">To:</div>
          <p>
              ${whAddress}<br>
          </p>
          
      </td>
  </tr>
  <tr>
    <td><span class="sideHead">GST:</span>
      <p>${salesAccountGst}</p>
    </td>
    <td><span class="sideHead">GST:</span>
      <p>${gst}</p>
    </td>
  </tr>
      </table>
      <p style="padding: 5px 10px 15px 10px;">
          <strong>WE ARE RETURNING HEREWITH THE DEFECTIVE MATERIALS AS DETAILED BELOW</strong><br>
          BELOW MATERIALS ARE NOT FOR SALE / RENT / LEASE<br>
          NO COMMERCIAL VALUE INVOLVED
      </p>
      <table class="defective-table" width="100%">
          <thead>
              <tr>
                  <td style="width:60px">SL No</td>
                  <td>Description</td>
                  <td>QTY</td>
              </tr>
          </thead>
          <tbody>
              <tr>
                  <td>1</td>
                  <td>
                    Set Top Boxes/ Smart Cards:
                  </td>
                  <td>${inWtyAssets.length + outWtyAssets.length + radAssets.length}</td>
              </tr>
              <tr>
                  <td></td>
                  <td>
                    <p class="subCategory">OUTWTY DEFECTIVE:</p><div class="list">${outWtyAssetslist}</div>
                  </td>
                  <td class="subCategory">${outWtyAssets.length}</td>
              </tr>
              <tr>
                  <td></td>
                  <td>
                    <p class="subCategory">INWTY DEFECTIVE:</p><div class="list">${inWtyAssetslist}</div>
                  </td>
                  <td class="subCategory">${inWtyAssets.length}</td>
              </tr>
              <tr>
                  <td></td>
                  <td>
                    <p class="subCategory">RECEIVED AS DEFEVTIVE:</p><div class="list">${radAssetslist}</div>
                  </td>
                  <td class="subCategory">${radAssets.length}</td>
              </tr>
          </tbody>
      </table>
  </body>
  </html>`
    return emailContent;
  }
  catch (error) {
    console.error("Error constructing email content:", error);
    throw error;
  }

}
const generateAssetList = (assets) => {
  return assets.map(asset => `<p>${asset.asset_number}&nbsp;${asset.smc || ''}&nbsp;${asset.faulty_sr_no || ''}</p>`).join('');
};