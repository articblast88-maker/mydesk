let client;
document.onreadystatechange = () => {
    if (document.readyState === 'complete') {
        init();
    }
}
async function init() {
    try {
        client = await app.initialized();
        const context = await client.instance.context();
        renderPage(context.data);
    } catch (err) {
        console.error('An error occurred while initializing the app', err);
    }
}
async function renderPage(data) {
    const columns = getColumnMapping();
    let assets = []

    if (data.usecase === "select") {
        columns.unshift({
            data: null,
            className: 'select-checkbox',
            orderable: false,
            defaultContent: '<fw-checkbox class="assetCheckbox"></fw-checkbox>',
            width: "20px"
        });
        const path = `distributor_code=${data.dtCode}&dc_no=%00&asset_status=Active&asset_status=In%20Repair&asset_status=Defective&asset_type=CARDLESS&asset_type=Set%20Top%20Box&page_size=100`
        const res = await client.request.invokeTemplate("filterAssetCustomObject", {
            context: { path }
        });
        const assetsResp = JSON.parse(res.response).records
        assets = assetsResp.filter(asset =>
            (asset.data.asset_status === 'Defective' && !asset.data.faulty_sr_no) ||
            ((asset.data.asset_status === 'Active' || asset.data.asset_status === 'In Repair') && asset.data.faulty_sr_no)
        );
        $("#submitBtn,#closeBtn").show();
    }
    else {
        const path = `dc_no=${data.dcNumber}&page_size=100`
        const res = await client.request.invokeTemplate("filterAssetCustomObject", {
            context: { path }
        });
        assets = JSON.parse(res.response).records
        $("#downloadBtn,#closeBtn").show()
    }

    const assetTable = initializeDataTable(assets, columns)

    $('#assetsTable tbody').on('click', 'td.dt-control', function () {
        const tr = $(this).closest('tr');
        const row = assetTable.row(tr);
        if (row.child.isShown()) {
            row.child.hide();
            tr.removeClass('shown');
        } else {
            row.child(format(row.data())).show();
            tr.addClass('shown');
        }
    });
    $('#assetsTable tbody').on('click', 'td.select-checkbox', function () {
        var selectedCount = $('td.select-checkbox').find('fw-checkbox[aria-checked="true"]').length;
        if (selectedCount >= data.assetsLimit) {
            $(this).find('fw-checkbox').prop('checked', 'false');
            document.querySelector('#type_toast_right').trigger({ type: 'error', content: 'Exceeded the limit' });
        }
    });

    $("#downloadBtn").off().on("fwClick", async () => {
        try {
            const assetDetails = assets.map(asset => ({
                swap_category: asset.data.swap_category,
                asset_status: asset.data.asset_status,
                smc: asset.data.smc,
                faulty_sr_no: asset.data.faulty_sr_no,
                asset_number: asset.data.asset_number
            }));
            const resp = await client.request.invoke("getEmailContent", { assetDetails, dcNumber: data.dcNumber, emailID: data.emailID, submittedDate: data.dcSubmittedTime });
            const contentHtml = resp.response.emailContent;
            const element = document.createElement('div');
            element.innerHTML = contentHtml;
            html2pdf(element, { margin: 10, filename: `DC-NUMBER-${data.dcNumber}.pdf` });
        }
        catch (error) {
            document.querySelector('#type_toast_right').trigger({ type: 'error', content: 'Download Failed' });
            console.log("Failed to get content", error)
        }

    });

    $("#closeBtn").off().on("fwClick", () => client.instance.close());

    $("#submitBtn").off().on("click", async function () {
        const selectedAssets = [];

        assetTable.rows().every(function () {
            const checked = $(this.node()).find(".assetCheckbox").prop("checked")
            if (checked) {
                var assetData = this.data();
                selectedAssets.push(assetData.display_id);
            }
        });

        if (selectedAssets.length > 0) {
            const payload = {
                ticketId: data.ticketId,
                dcCreatedDate: data.dcCreatedDate,
                dtCode: data.dtCode,
                dtName: data.dtName,
                region: data.region,
                selectedAssets
            };
            sendToParentLocation(payload);
        } else {
            document.querySelector('#type_toast_right').trigger({ type: 'error', content: 'Please select at least one asset' });
        }
    });
}
function getColumnMapping() {
    return [
        {
            className: 'dt-control',
            orderable: false,
            data: null,
            defaultContent: '',
            width: "20px"
        },
        {
            data: "data.asset_number",
            title: "STB#",
            width: "95px"
        },
        {
            data: "data.smc",
            title: "SMC#",
            width: "85px"
        },
        {
            data: "data.faulty_sr_no",
            title: "Faulty SR#",
            render: function (data) {
                return data || "-";
            }
        },
        {
            data: "data.receipt_category",
            title: "Receipt Category",
            render: function (data) {
                return data || "-";
            }
        }
    ]
}
function format(data) {
    return `
        <div class="details-container">
            <div class="line">
                <p class="field-section"><span class="fieldName label">Asset status:</span> ${data.data.asset_status || "—"}</p>
                <p class="field-section"><span class="fieldName label">Asset Service Type:</span> ${data.data.asset_service_type || "—"}</p>
            </div>
            <div class="line">
                <p class="field-section"><span class="fieldName label">Asset Shipping Status:</span> ${data.data.asset_shipping_status || "—"}</p>
                <p class="field-section"><span class="fieldName label">STN#:</span> ${data.data.stn_number || "—"}</p>
            </div>
            <div class="line">
                <p class="field-section"><span class="fieldName label">Swap Category:</span> ${data.data.swap_category || "—"}</p>
            </div>
        </div>`;
}

async function sendToParentLocation(payload) {
    try {
        await client.instance.send({ message: payload });
        client.instance.close();
    } catch (error) {
        console.error("Failed to send response back to parent window.", error);
        client.instance.close();
    }
}

function initializeDataTable(data, columns) {
    return $('#assetsTable').DataTable({
        data,
        columns,
        info: false,
        ordering: false,
        paging: false,
        destroy: true,
        searching: false,
        autoWidth: false,
        initComplete: function () { $("#loader").hide(); }
    });
}